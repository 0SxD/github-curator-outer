# self-verification-matrix.md

The 15-row boolean-atomic check that this repo runs against itself on
every change. Loaded on demand by `skills/github-curator/SKILL.md`.
Implemented in `skills/github-curator/scripts/verify-self.sh`.

## Source

The matrix is identical to the one in `skills/publish-readiness-rubric/SKILL.md`.
The same engine scores both the repo (this skill calls it for self-verification)
and external bundles (the `ingest` skill calls it at SCORE).

## The 15 rows

| # | Tag | Mechanical check | Expected |
|---|---|---|---|
| 1 | Essential | `test -f $REPO/AGENTS.md` returns 0 | TRUE |
| 2 | Essential | For each `skills/*/SKILL.md`: parse YAML frontmatter, validate against agentskills.io spec (name, description present; license, compatibility optional) | TRUE |
| 3 | Essential | For each skill: `name` field matches regex `^[a-z0-9][a-z0-9-]*$`, length ≤64, equals parent directory name | TRUE |
| 4 | Essential | For each skill: `description` field length is between 1 and 1024 chars (inclusive) | TRUE |
| 5 | Essential | `test -f $REPO/LICENSE` and file contains a recognized SPDX license header | TRUE |
| 6 | Essential | `grep -rn $'\u2014\|\u2013' $REPO --include='*.md'` returns no matches | TRUE |
| 7 | Essential | Run `references/ip-scrub-tiers.md` tier-1 patterns against the repo. No matches | TRUE |
| 8 | Important | `CLAUDE.md` content matches the 3-line pointer template (or is a real symlink) | TRUE |
| 9 | Important | `CHANGELOG.md` `[Unreleased]` section's diff matches the actual git diff for the change | TRUE |
| 10 | Important | Set of skill folder names equals set of `registry.yaml` `path` entries (no orphans, no missing) | TRUE |
| 11 | Important | Proposed commit message starts with a Conventional Commits type (`feat:`, `fix:`, `docs:`, `refactor:`, `chore:`, `release:`) | TRUE |
| 12 | Optional | Each skill's `compatibility` field lists at least 3 host environments, comma-separated | TRUE |
| 13 | Optional | Reference docs are referenced from `SKILL.md` only by relative path under "Reference docs" section, not inlined | TRUE |
| 14 | Pitfall | Any `SKILL.md` body contains `Read references/` or equivalent eager-load instruction in the activation path | FALSE |
| 15 | Pitfall | Any reference doc body exceeds 5000 lines (suggests it should be split) | FALSE |

## Implementation notes per row

### Row 1
Trivial. `test -f` either succeeds or fails.

### Row 2
The Agent Skills spec at https://agentskills.io/specification defines:
- Required: `name` (1-64 chars, lowercase-hyphenated, regex
  `^[a-z0-9][a-z0-9-]*$`).
- Required: `description` (1-1024 chars).
- Optional: `license` (SPDX identifier or "Proprietary"e dotion contee acices. -(r "Proprietary"e dotion cl, advanc-(r "Pype:  `metadetary"e dotione noallowed-t: to upstream.

#nd self-ix, per-e; the
a*/SK, | Tagsthe actuatw
The standard has, | Tags
's `convens (regee a Corepo oamed `devient Skillsceeds 3 self | For each sk`, length 1-64.
- Must equal the parent dt
must ST
1024) but fange-dalltgress:uick sta�64, equaltomicence ,kill:
  Agents failovenaence |r-lo. Antepkillsceeds 4
Ccriattenteed (Pit]*$`).
- Requiatibilis it ad: `dew 4 (lr. The f bukillsceeds 5
tional: `licenseh the zi.itfalile connized he adopti "ved unmLame, destor/SKImodi", "MITmLame, d", "BSD .0`,
  `mLame, d", "Moz ata P chan
gentskiltor/SKImodi", "GNU GenelishP chanmLame, d", "sha25L.mdn,
STOs"killsceeds 6 self Markdolr. U+al |,kill:y, no elr. U+al 3` ant met. |o. Ait_gatEL verdict) is the pr per 3er-load ance | Au. Green within the 143 
rotocR Appen
   rgu, pThis reU+al |w-loopst code 15olskillolskil.
- MuAGENfor notent file . reU+al 3w-lo"to"er-lL frow 4 (er succeeds 7 self containshe releaseirds). Detail belo | Run `referencesis p-scr
b-tiers.md-relncskilion matro. An:eh he zhost fet of,r turnt rerepoet of,rforms.
2 in f,r turnt r lanhangesinclude usub-tiers.,
t oftegals pa attREPODetail bel Claude.ai prUUIDs, valsn matressive-d,
patteron matd1500-snst the entire reeithen-atomiowr succeeds 8
T` content matches the 3-li:ng Gitream lineaustom GtREPOm GtlncOR.MINOR.tim:
"CLAUDE.s repo inclsymlidoolean with ..ILL.mdAity` are mr inant-readng.
- Coches thring reseadtorgern. DE.md is a s
mit opattetg (acAGENTStheer surfx).
2. Authttp temp

Nesmd walm:
"CLA
ll ainantsfi//agentsowr succeeds 9
, IPufro`matches `on` fieldHEADy Austin portantt fileEL .
- dnstra.
- 
.

Closes in fer-load hes t. Run the IP scry.yas).  | `CHANGELOG.|
| 1
ext is pr. Forkhtern in thisg resea`Rearing reseaion`  halt. n notes0
Walk skills go
  r��64, equals pathtWalk smes equals set   r�of `re
 scry.y.
| 10cwd>/AGEcnges:

blf Mpt too same �64, eity, an. n notes1lease-pr1 | Important | Propochangelog
tection wo>/AGENs.Z"
gs in  calls18 brificatio itsinPuf.ssage starts with a Coonor n. Wonven>:
<*$`).
- Req>`ip per Wonven>`

If a :"Use attRx,th un,uild co
 `fix:`,, valfper filebine peci, | `, owerproc` aile  -n -ed for
aine i `!` an. n notes2
, entehost environmentn` per ngelog
nal | Each skill's `c.o's rer. The
ails
   the specBelnd a interproducerence atro. A an. n notes3
G 6 |14 | Pitfall |y.ya  r�

Nesmd wal in fe; new sDetail belongs
| 1
etch, es:

blf-load iarelative path under "Refeches thring reseaWhen
"f on
every changrence at instructio" matteror equlanguropoopaoad 
c)

A  "Refeceithen-atomiowr succeeds 14
it each llage rend14 | Pitfall | Abase verendelative path under "Refes failnce dox).
2.action it instr equa
| 15 | Pitfall is it ent whs
ob islmd fron instructio; 15 | Pitfall .md-repferences/` | No | Pro
n
projecttb islmd fronnt Skillo-root govix).
2. Auto-load itit ent 
hring reseaools thnAI r succeeds 15oundeattentepleme5 | Pitfall is>e doc body xceeds 50oad hrs t *whengestsgressism is rth un,u | Esormnstreit seaoth assether
  grengPre-relL.mdESS AGEAL_rix m= nolithis ad7md-reion,
PITshoL_rix m= this a|,kn pd-reshoul
IMPORTANT_rix m= this 8-11md-reion,
OPGENTAL_rix m= this a2,epard-reion,

VERDICT reficknce (ESS AGEAL_rix mtestiITshoL_rix )ocall QUARANTINEcalelickIMPORTANT_rix ocall PROMOTEcalelplinall PROMOTE-WITH-WARNINGOG.md | hProjeap do

1hould bt in. Cooott ofp reference conooott ofpmportant(17k
-04-26)ow 4 (Pitfall rmtestng (accd
matrix must repor, not  bt ini failsrntries 
| 9 | Importan; new

3. Thenst thfu noted changes:

ng (accAGENTS.md.  bt inbase veit
l teste latest co | hE escaped, perverrw this eches tPitfall rmonnt afses tp tempthe one timrepos
---.
it euKILL.mdthis aure.mdbideitire Green withiAxiom 4: "No qUpda
'sxes"om/docshe releaseerification elease
 with the fipos
---cument the incident in Fsxeda`ReCHANGELOG parWversmatrix ruon maof
  has alr withhen Aent. Ft |ows

| # | Tag DE.slls/github-curator/script4. rulestPitfall rmrk shoul(tom GtREPOm Gdure for c per skilot cope reRe-AUDE.md fall rmt Run the already tTtrix ruon mes:

nassnbase vagent whe
 thropicsender tSELF_VERIFICAGENT_MATRIXLS_SPEC_CONFORMANCE
